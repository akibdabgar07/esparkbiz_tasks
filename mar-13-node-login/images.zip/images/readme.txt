Green Color : #174F2A
Gold Color : #A4843F
white : #ffffff
black: #000000
Red : #FF0000